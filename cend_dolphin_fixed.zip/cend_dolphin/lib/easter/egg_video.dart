import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:video_player/video_player.dart';

/// Ubah nilai ini jika watermark masih terlihat atau terlalu banyak
/// terpotong. 0.12 berarti 12% bagian ATAS video disembunyikan.
const double watermarkCropTopPercent = 0.12;
const double watermarkCropBottomPercent = 0.0;
const double watermarkCropLeftPercent = 0.0;
const double watermarkCropRightPercent = 0.0;

const String eggVideoUrl = 'https://files.catbox.moe/z9l7mh.mp4';

class EggVideoScreen extends StatefulWidget {
  const EggVideoScreen({super.key});
  @override
  State<EggVideoScreen> createState() => _EggVideoScreenState();
}

class _EggVideoScreenState extends State<EggVideoScreen> {
  VideoPlayerController? _c;
  String status = 'Menyiapkan...';
  bool error = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      status = 'Memuat...';
      error = false;
    });
    try {
      final dir = await getApplicationSupportDirectory();
      final f = File('${dir.path}/egg_cache.mp4');
      if (!(await f.exists()) || await f.length() == 0) {
        final r = await http
            .get(Uri.parse(eggVideoUrl))
            .timeout(const Duration(seconds: 60));
        if (r.statusCode != 200) throw 'HTTP ${r.statusCode}';
        await f.writeAsBytes(r.bodyBytes);
      }
      final c = VideoPlayerController.file(f);
      await c.initialize();
      await c.play();
      if (!mounted) return;
      setState(() {
        _c = c;
        status = '';
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = true;
        status = 'Gagal memuat video. Cek koneksi internet.';
      });
    }
  }

  @override
  void dispose() {
    _c?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        body: GestureDetector(
          onTap: () => Navigator.of(context).pop(),
          child: SizedBox.expand(
            child: _c != null && _c!.value.isInitialized
                ? _croppedVideo(_c!)
                : Center(
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      if (!error) const CircularProgressIndicator(color: Colors.white),
                      const SizedBox(height: 12),
                      Text(status, style: const TextStyle(color: Colors.white)),
                      if (error) ...[
                        const SizedBox(height: 12),
                        ElevatedButton(onPressed: _load, child: const Text('COBA LAGI')),
                      ],
                    ]),
                  ),
          ),
        ),
      );

  /// Menyembunyikan watermark dengan memotong sisi atas/bawah/kiri/kanan
  /// video lalu memperbesar sisanya agar memenuhi layar (tanpa mengubah
  /// file asli). Pendekatan: bungkus video asli dalam kotak berukuran
  /// (1-crop) dari ukurannya, geser video ke dalam kotak itu memakai
  /// Align, lalu seluruh kotak di-cover ke layar dengan FittedBox.
  Widget _croppedVideo(VideoPlayerController c) {
    final vw = c.value.size.width;
    final vh = c.value.size.height;
    final visW = vw * (1 - watermarkCropLeftPercent - watermarkCropRightPercent);
    final visH = vh * (1 - watermarkCropTopPercent - watermarkCropBottomPercent);

    // Alignment video di dalam kotak crop: -1..1. Karena bagian ATAS
    // video harus dibuang, video digeser ke ATAS (keluar kotak) sehingga
    // yang tersisa di kotak adalah bagian BAWAHnya.
    final dx = visW == vw
        ? 0.0
        : ((watermarkCropLeftPercent - watermarkCropRightPercent) / (1 - visW / vw))
            .clamp(-1.0, 1.0);
    final dy = visH == vh
        ? 0.0
        : ((watermarkCropTopPercent - watermarkCropBottomPercent) / (1 - visH / vh))
            .clamp(-1.0, 1.0);

    return ClipRect(
      child: FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(
          width: visW,
          height: visH,
          child: ClipRect(
            child: Align(
              alignment: Alignment(dx, dy),
              widthFactor: visW / vw,
              heightFactor: visH / vh,
              child: SizedBox(width: vw, height: vh, child: VideoPlayer(c)),
            ),
          ),
        ),
      ),
    );
  }
}
