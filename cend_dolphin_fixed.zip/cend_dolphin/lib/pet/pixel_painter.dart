import 'package:flutter/material.dart';

/// Painter generik: menggambar sprite dari daftar baris string.
/// Satu karakter = satu warna pada [palette]. '.' = transparan.
class PixelSpritePainter extends CustomPainter {
  final List<String> rows;
  final Map<String, Color> palette;
  PixelSpritePainter(this.rows, this.palette);

  @override
  void paint(Canvas canvas, Size size) {
    if (rows.isEmpty) return;
    final cols = rows.first.length;
    final rowCount = rows.length;
    final cell = size.width / cols;
    final cellH = size.height / rowCount;
    final paint = Paint()..isAntiAlias = false;
    for (int y = 0; y < rowCount; y++) {
      final row = rows[y];
      int x = 0;
      while (x < row.length) {
        final ch = row[x];
        int end = x + 1;
        while (end < row.length && row[end] == ch) {
          end++;
        }
        final color = palette[ch];
        if (color != null) {
          paint.color = color;
          canvas.drawRect(
              Rect.fromLTWH(x * cell, y * cellH, (end - x) * cell, cellH),
              paint);
        }
        x = end;
      }
    }
  }

  @override
  bool shouldRepaint(covariant PixelSpritePainter old) =>
      old.rows != rows || old.palette != palette;
}

class PixelSprite extends StatelessWidget {
  final List<String> rows;
  final Map<String, Color> palette;
  final double size;
  const PixelSprite(
      {super.key, required this.rows, required this.palette, this.size = 160});

  @override
  Widget build(BuildContext context) => SizedBox(
        width: size,
        height: size,
        child: CustomPaint(painter: PixelSpritePainter(rows, palette)),
      );
}
