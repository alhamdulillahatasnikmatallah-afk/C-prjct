import 'package:flutter/material.dart';
import 'package:cend_dolphin/core/theme.dart';
import 'package:cend_dolphin/core/sound.dart';
import 'package:cend_dolphin/pet/pet_model.dart';
import 'package:cend_dolphin/pet/select_screen.dart';

class SettingsScreen extends StatefulWidget {
  final PetState state;
  const SettingsScreen({super.key, required this.state});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late PetState s = widget.state;

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: PastelPalette.cream,
        appBar: AppBar(
          backgroundColor: PastelPalette.cream,
          elevation: 0,
          title: Text('Pengaturan', style: roundedText(16, PastelPalette.brown)),
          iconTheme: const IconThemeData(color: PastelPalette.brown),
        ),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          Text('Background', style: roundedText(13, PastelPalette.brown, w: FontWeight.w700)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: Background.values
                .map((b) => ChoiceChip(
                      label: Text(b.label),
                      selected: s.background == b,
                      onSelected: (_) {
                        Sfx.i.click();
                        setState(() => s.background = b);
                        PetStore.save(s);
                      },
                    ))
                .toList(),
          ),
          const SizedBox(height: 20),
          SwitchListTile(
            title: Text('Suara', style: roundedText(13, PastelPalette.brown)),
            value: Sfx.i.soundOn,
            onChanged: (v) {
              Sfx.i.setSound(v);
              setState(() {});
            },
          ),
          SwitchListTile(
            title: Text('Getar', style: roundedText(13, PastelPalette.brown)),
            value: Sfx.i.vibrateOn,
            onChanged: (v) {
              Sfx.i.setVibrate(v);
              setState(() {});
            },
          ),
          const SizedBox(height: 12),
          ListTile(
            title: Text('Ganti pet', style: roundedText(13, PastelPalette.brown)),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const SelectPetScreen())),
          ),
          ListTile(
            title: Text('Reset data pet ini', style: roundedText(13, Colors.red)),
            trailing: const Icon(Icons.delete_outline, color: Colors.red),
            onTap: _confirmReset,
          ),
          const SizedBox(height: 20),
          Text('Support Admin', style: roundedText(13, PastelPalette.brown, w: FontWeight.w700)),
          const SizedBox(height: 8),
          Text('support admin untuk menambah wawasan',
              style: roundedText(11, PastelPalette.brownSoft)),
          const SizedBox(height: 10),
          Container(
            color: Colors.white,
            padding: const EdgeInsets.all(10),
            child: Image.asset('assets/images/qris.jpeg',
                filterQuality: FilterQuality.none),
          ),
          const SizedBox(height: 20),
          Text('project ini tahap pengembangan',
              textAlign: TextAlign.center,
              style: roundedText(11, PastelPalette.brownSoft)),
        ]),
      );

  void _confirmReset() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Hapus data ${s.name}?'),
        content: const Text('Ini tidak bisa dibatalkan.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('BATAL')),
          TextButton(
            onPressed: () async {
              final fresh = PetState(kind: s.kind, name: s.kind.label);
              await PetStore.save(fresh);
              if (mounted) {
                Navigator.pop(context);
                Navigator.of(context).pushReplacement(
                    MaterialPageRoute(builder: (_) => const SelectPetScreen()));
              }
            },
            child: const Text('HAPUS', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}
