import 'package:flutter/material.dart';
import 'package:cend_dolphin/core/theme.dart';

class StatBar extends StatelessWidget {
  final String label;
  final double value; // 0..100
  final Color color;
  const StatBar(
      {super.key, required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) => Row(children: [
        SizedBox(width: 60, child: Text(label, style: roundedText(11, PastelPalette.brown))),
        Expanded(
          child: Stack(children: [
            Container(
              height: 12,
              decoration: BoxDecoration(
                  color: PastelPalette.creamDark,
                  borderRadius: BorderRadius.circular(8)),
            ),
            FractionallySizedBox(
              widthFactor: (value / 100).clamp(0, 1),
              child: Container(
                height: 12,
                decoration:
                    BoxDecoration(color: color, borderRadius: BorderRadius.circular(8)),
              ),
            ),
          ]),
        ),
      ]);
}

class SpeechBubble extends StatelessWidget {
  final String text;
  const SpeechBubble({super.key, required this.text});
  @override
  Widget build(BuildContext context) => AnimatedSwitcher(
        duration: const Duration(milliseconds: 220),
        child: text.isEmpty
            ? const SizedBox.shrink(key: ValueKey('empty'))
            : Container(
                key: ValueKey(text),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: const [
                    BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, 2))
                  ],
                ),
                child: Text(text, style: roundedText(12, PastelPalette.brown)),
              ),
      );
}

class RoundButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const RoundButton({super.key, required this.icon, required this.label, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle, boxShadow: [
              BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, 2))
            ]),
            child: Icon(icon, color: PastelPalette.brown, size: 22),
          ),
          const SizedBox(height: 4),
          Text(label, style: roundedText(9, PastelPalette.brown)),
        ]),
      );
}
