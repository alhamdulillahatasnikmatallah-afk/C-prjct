import 'package:flutter/material.dart';
import 'package:cend_dolphin/ui/term_widgets.dart';
import 'package:cend_dolphin/tools/sensor_lab.dart';
import 'package:cend_dolphin/tools/encode_tools.dart';
import 'package:cend_dolphin/tools/net_tools.dart';
import 'package:cend_dolphin/tools/privacy_tools.dart';
import 'package:cend_dolphin/tools/daily_tools.dart';
import 'package:cend_dolphin/tools/linux_shell_screen.dart';

class ToolsHomeScreen extends StatelessWidget {
  const ToolsHomeScreen({super.key});

  @override
  Widget build(BuildContext context) => TermScaffold(
        title: 'C PROJECT // TOOLS',
        child: ListView(padding: const EdgeInsets.only(bottom: 20), children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(12, 12, 12, 4),
            child: Text('01  MULTIPURPOSE', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.4)),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 12),
            child: Text('Utilities edukasi yang tersedia di aplikasi', style: TextStyle(fontSize: 12)),
          ),
          TermListTile(label: 'SENSOR LAB', icon: Icons.sensors, onTap: () => _go(context, const SensorLabScreen())),
          TermListTile(label: 'ENCODE & HASH', icon: Icons.code, onTap: () => _go(context, const EncodeToolsScreen())),
          TermListTile(label: 'NETWORK UTILITIES', icon: Icons.wifi, onTap: () => _go(context, const NetToolsScreen())),
          TermListTile(label: 'DAILY UTILITIES', icon: Icons.calculate, onTap: () => _go(context, const DailyToolsScreen())),
          TermListTile(label: 'PRIVACY TOOLS', icon: Icons.shield, onTap: () => _go(context, const PrivacyToolsScreen())),
          const Padding(
            padding: EdgeInsets.fromLTRB(12, 24, 12, 4),
            child: Text('02  NETWORK & SECURITY LAB', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.1)),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 12),
            child: Text('PTY shell Android dan akses ke Termux untuk Bash/Linux userspace.', style: TextStyle(fontSize: 12)),
          ),
          TermListTile(label: 'OPEN INTERACTIVE SHELL', icon: Icons.terminal, onTap: () => _go(context, const LinuxShellScreen())),
        ]),
      );

  void _go(BuildContext ctx, Widget page) =>
      Navigator.of(ctx).push(MaterialPageRoute(builder: (_) => page));
}
