import 'dart:async';
import 'package:flutter/material.dart';
import 'package:sensors_plus/sensors_plus.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:cend_dolphin/ui/term_widgets.dart';
import 'package:cend_dolphin/core/theme.dart';

class SensorLabScreen extends StatefulWidget {
  const SensorLabScreen({super.key});
  @override
  State<SensorLabScreen> createState() => _SensorLabScreenState();
}

class _SensorLabScreenState extends State<SensorLabScreen> {
  String accel = '-', gyro = '-', mag = '-';
  int battLevel = 0;
  BatteryState battState = BatteryState.unknown;
  String model = '...', android = '...', abi = '...', ram = '...';
  StreamSubscription? sAccel, sGyro, sMag, sBatt;
  Timer? pollTimer;
  final battery = Battery();

  @override
  void initState() {
    super.initState();
    _loadDevice();
    _pollBattery();
    pollTimer = Timer.periodic(const Duration(milliseconds: 500), (_) {
      try {
        sAccel ??= accelerometerEventStream().listen((e) {
          if (mounted) {
            setState(() =>
                accel = 'x:${e.x.toStringAsFixed(1)} y:${e.y.toStringAsFixed(1)} z:${e.z.toStringAsFixed(1)}');
          }
        });
        sGyro ??= gyroscopeEventStream().listen((e) {
          if (mounted) {
            setState(() =>
                gyro = 'x:${e.x.toStringAsFixed(1)} y:${e.y.toStringAsFixed(1)} z:${e.z.toStringAsFixed(1)}');
          }
        });
        sMag ??= magnetometerEventStream().listen((e) {
          if (mounted) {
            setState(() =>
                mag = 'x:${e.x.toStringAsFixed(1)} y:${e.y.toStringAsFixed(1)} z:${e.z.toStringAsFixed(1)}');
          }
        });
      } catch (_) {}
    });
    sBatt = battery.onBatteryStateChanged.listen((st) {
      if (mounted) setState(() => battState = st);
    });
  }

  Future<void> _loadDevice() async {
    try {
      final i = await DeviceInfoPlugin().androidInfo;
      if (mounted) {
        setState(() {
          model = '${i.manufacturer} ${i.model}';
          android = '${i.version.release} (API ${i.version.sdkInt})';
          abi = i.supportedAbis.isNotEmpty ? i.supportedAbis.first : '-';
        });
      }
    } catch (_) {}
  }

  Future<void> _pollBattery() async {
    try {
      final l = await battery.batteryLevel;
      if (mounted) setState(() => battLevel = l);
    } catch (_) {}
    Future.delayed(const Duration(seconds: 3), _pollBattery);
  }

  @override
  void dispose() {
    sAccel?.cancel();
    sGyro?.cancel();
    sMag?.cancel();
    sBatt?.cancel();
    pollTimer?.cancel();
    super.dispose();
  }

  Widget _row(String k, String v) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(k, style: termText(11, TermPalette.dim)),
          const SizedBox(height: 3),
          Text(v, style: termText(13, TermPalette.text)),
        ]),
      );

  @override
  Widget build(BuildContext context) => TermScaffold(
        title: 'SENSOR LAB',
        child: ListView(children: [
          _row('AKSELEROMETER', accel),
          _row('GIROSKOP', gyro),
          _row('KOMPAS (MAGNET)', mag),
          _row('BATERAI', '$battLevel%  ${battState.name}'),
          _row('MODEL HP', model),
          _row('ANDROID', android),
          _row('ARSITEKTUR (ABI)', abi),
          Text('Catatan: sensor cahaya/jarak tidak tersedia di semua HP.',
              style: termText(10, TermPalette.dim)),
        ]),
      );
}
