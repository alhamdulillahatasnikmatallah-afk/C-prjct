import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Pengelola suara & getar global. Semua pemanggilan aman (try/catch),
/// tidak pernah melempar error ke pemanggil.
class Sfx {
  Sfx._();
  static final Sfx i = Sfx._();

  final AudioPlayer _p = AudioPlayer()..setPlayerMode(PlayerMode.lowLatency);
  bool soundOn = true;
  bool vibrateOn = true;

  Future<void> loadPrefs() async {
    try {
      final sp = await SharedPreferences.getInstance();
      soundOn = sp.getBool('sfx_sound') ?? true;
      vibrateOn = sp.getBool('sfx_vibrate') ?? true;
    } catch (_) {}
  }

  Future<void> setSound(bool v) async {
    soundOn = v;
    try {
      final sp = await SharedPreferences.getInstance();
      await sp.setBool('sfx_sound', v);
    } catch (_) {}
  }

  Future<void> setVibrate(bool v) async {
    vibrateOn = v;
    try {
      final sp = await SharedPreferences.getInstance();
      await sp.setBool('sfx_vibrate', v);
    } catch (_) {}
  }

  Future<void> play(String name) async {
    if (soundOn) {
      try {
        await _p.stop();
        await _p.play(AssetSource('sounds/$name.wav'), volume: 1.0);
      } catch (_) {}
    }
    if (vibrateOn) {
      try {
        await HapticFeedback.selectionClick();
      } catch (_) {}
    }
  }

  void click() => play('click');
  void happy() => play('happy');
  void angry() => play('angry');
  void eat() => play('eat');
  void levelup() => play('levelup');
  void error() => play('error');
  void splash() => play('splash');
}
