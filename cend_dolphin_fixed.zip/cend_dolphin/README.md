# Cend Dolphin — Multipurpose & Network/Security Lab

Flutter Android app. Main tools screen is organized into two sections:

- **Multipurpose:** Sensor Lab, Encode & Hash, Network Utilities, Daily Utilities, and Privacy Tools.
- **Network & Security Lab:** interactive PTY-backed Android shell (`/system/bin/sh`) and a shortcut to open Termux.

## Important shell distinction

The in-app terminal launches Android's real `/system/bin/sh` through a pseudo-terminal (PTY). Stock Android does **not** ship GNU Bash or a full Linux distribution, so this is a real Android shell, not a bundled Linux/Bash environment. The **TERMUX BASH** action opens the installed Termux app, where Bash and Linux packages can be installed. Termux must be installed separately. This project does not bundle a complete Linux root filesystem.

## Project Structure

```
.
├── .github/
│   └── workflows/
│       └── build.yml          # GitHub Actions – build debug APK
└── cend_dolphin/
    ├── lib/
    ├── tool/
    │   └── patch_android.py   # auto-patch manifest + minSdk
    ├── assets/
    ├── pubspec.yaml
    └── README.md
```

## Build with GitHub Actions

1. Push this whole repository (including `.github/`) to GitHub.
2. Go to **Actions** tab → select **Build APK** → **Run workflow**.
3. After it finishes, download the artifact `cend-dolphin-debug-apk`.

The workflow will:
- Create Android platform scaffolding (`flutter create --platforms=android`)
- Apply the manifest + minSdk patch
- Resolve dependencies
- Build a **debug APK**

No need to extract or run anything manually on your machine for the CI build.

## Local Build (optional)

```bash
cd cend_dolphin
flutter create --platforms=android .
python3 tool/patch_android.py
flutter pub get
flutter build apk --debug
```

## Status

Source and workflow are prepared. A successful CI build + real-device smoke test are recommended to fully verify PTY behavior.

## Responsible use

Use the shell for your own device and authorized labs only. Network modules should be limited to diagnostics and systems you own or have permission to test.
